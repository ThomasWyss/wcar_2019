var classlirc_1_1client_1_1SetModeCommand =
[
    [ "__init__", "classlirc_1_1client_1_1SetModeCommand.html#a274b8a1d9045419a3a7ee13d2caa68e8", null ]
];