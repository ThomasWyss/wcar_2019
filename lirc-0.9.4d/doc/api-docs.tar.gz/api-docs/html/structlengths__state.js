var structlengths__state =
[
    [ "average", "structlengths__state.html#a78e239c985d538b4a285de8501dcb650", null ],
    [ "count", "structlengths__state.html#a28c55c710a63705fc89a5a578010960a", null ],
    [ "data", "structlengths__state.html#ac5f9366b2e7474643a6d9fac314c4503", null ],
    [ "first_signal", "structlengths__state.html#ab317f1c80e56b41abbaf21801f2152a3", null ],
    [ "header", "structlengths__state.html#a2bf3e532232f4582f7b5f64a67b19a3e", null ],
    [ "keypresses", "structlengths__state.html#a5ba133f3076964dba14d621d8be2a335", null ],
    [ "keypresses_done", "structlengths__state.html#a2044804fca25b7d5daa57bbc3a44605a", null ],
    [ "maxspace", "structlengths__state.html#a7519317c7482da2b2923f86a0161228a", null ],
    [ "mode", "structlengths__state.html#a85d1fe0f229a8532bac6c90be30a2e61", null ],
    [ "remaining_gap", "structlengths__state.html#a8cefb586a8639c462dc8babe11a0b05d", null ],
    [ "retval", "structlengths__state.html#a40385e0ad31c7c262e8fd3dd3aacc65c", null ],
    [ "sum", "structlengths__state.html#a8e0fd528701e5e308274102d6b8cbb43", null ]
];