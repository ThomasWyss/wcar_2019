var searchData=
[
  ['open_5ffunc',['open_func',['../structdriver.html#aeea866dd70c1cb8296e99fbe706bacf5',1,'driver']]],
  ['option_5ffmt',['OPTION_FMT',['../driver_8c.html#a47ecbd16ae0f73ec16bf3186beea0e27',1,'driver.c']]],
  ['option_5ft',['option_t',['../structoption__t.html',1,'']]],
  ['options_5fget_5fapp_5floglevel',['options_get_app_loglevel',['../lirc__options_8c.html#a2e0ec345fba828920ffe10c85d4aa9c9',1,'options_get_app_loglevel(const char *app):&#160;lirc_options.c'],['../lirc__options_8h.html#a2e0ec345fba828920ffe10c85d4aa9c9',1,'options_get_app_loglevel(const char *app):&#160;lirc_options.c']]],
  ['options_5fset_5floglevel',['options_set_loglevel',['../lirc__options_8c.html#a21ea46a90d52096ab0a309317312b346',1,'options_set_loglevel(const char *optarg):&#160;lirc_options.c'],['../lirc__options_8h.html#a21ea46a90d52096ab0a309317312b346',1,'options_set_loglevel(const char *optarg):&#160;lirc_options.c']]],
  ['opts',['opts',['../structopts.html',1,'']]]
];
