var searchData=
[
  ['toggle_5fbit',['toggle_bit',['../structir__remote.html#afbc1dd399fff0771f4d060fce62cdbfe',1,'ir_remote']]],
  ['toggle_5fbit_5fmask',['toggle_bit_mask',['../structir__remote.html#ad1d35f0da36527d473c7d857231ec739',1,'ir_remote']]],
  ['toggle_5fcode',['toggle_code',['../structir__remote.html#ac80cecb60d0e4e77b01c3044df9d6713',1,'ir_remote']]],
  ['toggle_5fmask',['toggle_mask',['../structir__remote.html#a9744aba55e393727c08815e548a9f836',1,'ir_remote']]],
  ['toggle_5fstate',['toggle_state',['../structtoggle__state.html',1,'']]],
  ['transmit_2ec',['transmit.c',['../transmit_8c.html',1,'']]],
  ['transmit_2eh',['transmit.h',['../transmit_8h.html',1,'']]],
  ['transmit_5fstate',['transmit_state',['../structir__ncode.html#a29cc93e9a6e908dfe8904db34680ef1f',1,'ir_ncode']]],
  ['tty_5fclear',['tty_clear',['../group__driver__api.html#gaa680ad6c63aaac541fc85d61b73a46d1',1,'tty_clear(int fd, int rts, int dtr):&#160;serial.c'],['../group__driver__api.html#gaa680ad6c63aaac541fc85d61b73a46d1',1,'tty_clear(int fd, int rts, int dtr):&#160;serial.c']]],
  ['tty_5fcreate_5flock',['tty_create_lock',['../group__driver__api.html#gaa2128e719d5174e1210fcc8c532c82bd',1,'tty_create_lock(const char *name):&#160;serial.c'],['../group__driver__api.html#gaa2128e719d5174e1210fcc8c532c82bd',1,'tty_create_lock(const char *name):&#160;serial.c']]],
  ['tty_5fdelete_5flock',['tty_delete_lock',['../group__driver__api.html#ga94d6aff1542d08fcf32b5acdc735090e',1,'tty_delete_lock(void):&#160;serial.c'],['../group__driver__api.html#ga94d6aff1542d08fcf32b5acdc735090e',1,'tty_delete_lock(void):&#160;serial.c']]],
  ['tty_5fread',['tty_read',['../group__driver__api.html#ga76ea8c360d88f108399c5926b3bff16d',1,'tty_read(int fd, char *byte):&#160;serial.c'],['../group__driver__api.html#ga76ea8c360d88f108399c5926b3bff16d',1,'tty_read(int fd, char *byte):&#160;serial.c']]],
  ['tty_5freset',['tty_reset',['../group__driver__api.html#ga2cad04de039521ac1b0c14c42ba1b43c',1,'tty_reset(int fd):&#160;serial.c'],['../group__driver__api.html#ga2cad04de039521ac1b0c14c42ba1b43c',1,'tty_reset(int fd):&#160;serial.c']]],
  ['tty_5fset',['tty_set',['../group__driver__api.html#ga17fb600e510ec6919659e7fab74c3de6',1,'tty_set(int fd, int rts, int dtr):&#160;serial.c'],['../group__driver__api.html#ga17fb600e510ec6919659e7fab74c3de6',1,'tty_set(int fd, int rts, int dtr):&#160;serial.c']]],
  ['tty_5fsetbaud',['tty_setbaud',['../group__driver__api.html#ga44b60aca788c92e31b61298f534d2b2c',1,'tty_setbaud(int fd, int baud):&#160;serial.c'],['../group__driver__api.html#ga44b60aca788c92e31b61298f534d2b2c',1,'tty_setbaud(int fd, int baud):&#160;serial.c']]],
  ['tty_5fsetcsize',['tty_setcsize',['../group__driver__api.html#gaffeab51b57e1e8eaca6fc502f99e6c29',1,'tty_setcsize(int fd, int csize):&#160;serial.c'],['../group__driver__api.html#gaffeab51b57e1e8eaca6fc502f99e6c29',1,'tty_setcsize(int fd, int csize):&#160;serial.c']]],
  ['tty_5fsetdtr',['tty_setdtr',['../group__driver__api.html#ga7c9acb60305177b4498553782eb4fa3c',1,'tty_setdtr(int fd, int enable):&#160;serial.c'],['../group__driver__api.html#ga7c9acb60305177b4498553782eb4fa3c',1,'tty_setdtr(int fd, int enable):&#160;serial.c']]],
  ['tty_5fsetrtscts',['tty_setrtscts',['../group__driver__api.html#gafcab1b890be0e097640ff31f866ab94c',1,'tty_setrtscts(int fd, int enable):&#160;serial.c'],['../group__driver__api.html#gafcab1b890be0e097640ff31f866ab94c',1,'tty_setrtscts(int fd, int enable):&#160;serial.c']]],
  ['tty_5fwrite',['tty_write',['../group__driver__api.html#ga03233443b447b2de3a81b77a317663c4',1,'tty_write(int fd, char byte):&#160;serial.c'],['../group__driver__api.html#ga03233443b447b2de3a81b77a317663c4',1,'tty_write(int fd, char byte):&#160;serial.c']]],
  ['tty_5fwrite_5fecho',['tty_write_echo',['../group__driver__api.html#ga855e6cb4247f8359643a184a912d754d',1,'tty_write_echo(int fd, char byte):&#160;serial.c'],['../group__driver__api.html#ga855e6cb4247f8359643a184a912d754d',1,'tty_write_echo(int fd, char byte):&#160;serial.c']]]
];
