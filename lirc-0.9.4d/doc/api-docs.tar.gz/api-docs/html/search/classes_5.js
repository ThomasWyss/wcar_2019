var searchData=
[
  ['ir_5fcode_5fnode',['ir_code_node',['../structir__code__node.html',1,'']]],
  ['ir_5fncode',['ir_ncode',['../structir__ncode.html',1,'']]],
  ['ir_5fremote',['ir_remote',['../structir__remote.html',1,'']]]
];
