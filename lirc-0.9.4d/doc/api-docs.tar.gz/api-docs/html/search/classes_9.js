var searchData=
[
  ['toggle_5fstate',['toggle_state',['../structtoggle__state.html',1,'']]]
];
