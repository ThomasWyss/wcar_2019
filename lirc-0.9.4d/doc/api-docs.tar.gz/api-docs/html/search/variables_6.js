var searchData=
[
  ['gap',['gap',['../structir__remote.html#ab4e0daf0c0bb06e3feb707c401c92c0e',1,'ir_remote']]],
  ['gap2',['gap2',['../structir__remote.html#a096b15218256835f369f4fa701151971',1,'ir_remote']]],
  ['glob_5fchunk_5fsize',['GLOB_CHUNK_SIZE',['../driver_8c.html#a120e92d46830aa04786248a6821df39c',1,'driver.c']]]
];
