var searchData=
[
  ['logchannel_5ft',['logchannel_t',['../lirc__log_8h.html#abffd9aa4ab9bcfacdbb9d7728037114b',1,'lirc_log.h']]],
  ['loglevel_5ft',['loglevel_t',['../lirc__log_8h.html#a24e101a095456e946efea0b971fc2ee3',1,'lirc_log.h']]]
];
