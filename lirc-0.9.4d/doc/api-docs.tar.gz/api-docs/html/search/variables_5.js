var searchData=
[
  ['fd',['fd',['../structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f',1,'driver']]],
  ['features',['features',['../structdriver.html#acefa919d82609175b57967c5249020c0',1,'driver']]],
  ['flag',['flag',['../structflaglist.html#afe3283978a321862c7c7705e13206672',1,'flaglist']]],
  ['flags',['flags',['../structir__remote.html#a9ac03eb6d4cee793010b00fe434aa985',1,'ir_remote']]],
  ['freq',['freq',['../structir__remote.html#a04eb04a7c2333f53ceb20ffef8d2ebc4',1,'ir_remote']]]
];
