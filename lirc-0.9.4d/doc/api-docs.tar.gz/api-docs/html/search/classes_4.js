var searchData=
[
  ['gap_5fstate',['gap_state',['../structgap__state.html',1,'']]]
];
