var searchData=
[
  ['for_5feach_5fdriver',['for_each_driver',['../drv__admin_8c.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8h.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['for_5feach_5fplugin',['for_each_plugin',['../drv__admin_8c.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8h.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['free_5fconfig',['free_config',['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c'],['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c']]]
];
