var searchData=
[
  ['no_5ffoot_5frep',['NO_FOOT_REP',['../ir__remote__types_8h.html#a94aa4cc9b331962ec02258cc794077cc',1,'ir_remote_types.h']]],
  ['no_5fhead_5frep',['NO_HEAD_REP',['../ir__remote__types_8h.html#abf5d6878061b54bd7abcf78ba6336fd0',1,'ir_remote_types.h']]]
];
